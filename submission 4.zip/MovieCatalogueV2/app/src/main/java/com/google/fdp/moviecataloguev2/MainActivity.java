package com.google.fdp.moviecataloguev2;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.fdp.moviecataloguev2.fragments.FavouriteFragment;
import com.google.fdp.moviecataloguev2.fragments.MovieFragment;

import java.util.Objects;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    private BottomNavigationView navView;
    private Fragment pageContent;
    public  String KEY_FRAGMENT = MovieFragment.MOVIE_KEY;
    public String TITLE_FRAGMENT = "title";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        navView = findViewById(R.id.navView);
        navView.setOnNavigationItemSelectedListener(this);

        if (savedInstanceState == null) {
            openFragment(MovieFragment.newInstance(MovieFragment.MOVIE_KEY, false));
        } else {
            KEY_FRAGMENT = savedInstanceState.getString(TITLE_FRAGMENT);
            openFragment(Objects.requireNonNull(getSupportFragmentManager().getFragment(savedInstanceState, KEY_FRAGMENT)));
        }

    }

    private void openFragment(Fragment fragment) {
        pageContent = fragment;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.flContainer, pageContent, fragment.getClass().getSimpleName()).commit();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.setting_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_language_setting) {
            startActivity(new Intent(Settings.ACTION_LOCALE_SETTINGS));
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.navigation_movie:
                openFragment(MovieFragment.newInstance(MovieFragment.MOVIE_KEY, false));
                return true;
            case R.id.navigation_tv_show:
                openFragment(MovieFragment.newInstance(MovieFragment.TV_SHOW_KEY, false));
                return true;
            case R.id.navigation_favorite:
                openFragment(new FavouriteFragment());
                return true;
            default:
                return false;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString(TITLE_FRAGMENT, KEY_FRAGMENT);
        getSupportFragmentManager().putFragment(outState, KEY_FRAGMENT, pageContent);
        super.onSaveInstanceState(outState);
    }
}
