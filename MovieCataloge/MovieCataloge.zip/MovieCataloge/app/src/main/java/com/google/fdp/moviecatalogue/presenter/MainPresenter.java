package com.google.fdp.moviecatalogue.presenter;

import com.google.fdp.moviecatalogue.model.Movie;
import com.google.fdp.moviecatalogue.view.MainView;

import java.util.ArrayList;

/**
 * Created by gama on 2019-07-01.
 * Addin Gama Bertaqwa
 * addingama@gmail.com
 */
public class MainPresenter {
    private MainView view;
    private ArrayList<Movie> movies = new ArrayList<Movie>();

    public  MainPresenter(MainView view) {
        this.view = view;
    }

    public void buildMoviesData() {

        Movie movie1 = new Movie("Toy Story 4",
                "https://image.tmdb.org/t/p/w370_and_h556_bestv2/w9kR8qbmQ01HwnvK4alvnQ2ca0L.jpg",
                "June 21, 2019",
                "Woody has always been confident about his place in the world and that his priority is taking care of his kid, whether that's Andy or Bonnie. But when Bonnie adds a reluctant new toy called \"Forky\" to her room, a road trip adventure alongside old and new friends will show Woody how big the world can be for a toy.");

        Movie movie2 = new Movie("Spider-Man: Far from Home",
                "https://image.tmdb.org/t/p/w600_and_h900_bestv2/2cAc4qH9Uh2NtSujJ90fIAMrw7T.jpg",
                "July 2, 2019",
                "Peter Parker and his friends go on a summer trip to Europe. However, they will hardly be able to rest - Peter will have to agree to help Nick Fury uncover the mystery of creatures that cause natural disasters and destruction throughout the continent.");

        Movie movie3 = new Movie("Shazam!",
                "https://image.tmdb.org/t/p/w370_and_h556_bestv2/xnopI5Xtky18MPhK40cZAGAOVeV.jpg",
                "March 23, 2019",
                "A boy is given the ability to become an adult superhero in times of need with a single magic word.");
        Movie movie4 = new Movie("Alita: Battle Angel",
                "https://image.tmdb.org/t/p/w370_and_h556_bestv2/xRWht48C2V8XNfzvPehyClOvDni.jpg",
                "February 14, 2019",
                "When Alita awakens with no memory of who she is in a future world she does not recognize, she is taken in by Ido, a compassionate doctor who realizes that somewhere in this abandoned cyborg shell is the heart and soul of a young woman with an extraordinary past.");
        Movie movie5 = new Movie("Pet Sematary",
                "https://image.tmdb.org/t/p/w370_and_h556_bestv2/7SPhr7Qj39vbnfF9O2qHRYaKHAL.jpg",
                "April 5, 2019",
                "Dr. Louis Creed and his wife, Rachel, relocate from Boston to rural Maine with their two young children. The couple soon discover a mysterious burial ground hidden deep in the woods near their new home.");
        Movie movie6 = new Movie("Annabelle Comes Home",
                "https://image.tmdb.org/t/p/w370_and_h556_bestv2/jsbt03UnPPt14AYRMcGaoqtwNxQ.jpg",
                "June 26, 2019",
                "Determined to keep Annabelle from wreaking more havoc, demonologists Ed and Lorraine Warren bring the possessed doll to the locked artifacts room in their home, placing her “safely” behind sacred glass and enlisting a priest’s holy blessing. But an unholy night of horror awaits as Annabelle awakens the evil spirits in the room, who all set their sights on a new target—the Warrens' ten-year-old daughter, Judy, and her friends.");
        Movie movie7 = new Movie("Detective Conan: The Fist of Blue Sapphire",
                "https://image.tmdb.org/t/p/w370_and_h556_bestv2/1GyvpwvgswOrHvxjnw2FBLNkTyo.jpg",
                "April 12, 2019",
                "23rd movie in the \"Detective Conan\" franchise.");
        Movie movie8 = new Movie("John Wick: Chapter 3 - Parabellum",
                "https://image.tmdb.org/t/p/w370_and_h556_bestv2/ziEuG1essDuWuC5lpWUaw1uXY2O.jpg",
                "May 17, 2019",
                "Super-assassin John Wick returns with a $14 million price tag on his head and an army of bounty-hunting killers on his trail. After killing a member of the shadowy international assassin’s guild, the High Table, John Wick is excommunicado, but the world’s most ruthless hit men and women await his every turn.");
        Movie movie9 = new Movie("Aladdin",
                "https://image.tmdb.org/t/p/w370_and_h556_bestv2/3iYQTLGoy7QnjcUYRJy4YrAgGvp.jpg",
                "May 24, 2019",
                "A kindhearted street urchin named Aladdin embarks on a magical adventure after finding a lamp that releases a wisecracking genie while a power-hungry Grand Vizier vies for the same lamp that has the power to make their deepest wishes come true.");
        Movie movie10 = new Movie("Captain Marvel",
                "https://image.tmdb.org/t/p/w370_and_h556_bestv2/AtsgWhDnHTq68L0lLsUrCnM7TjG.jpg",
                "March 8, 2019",
                "The story follows Carol Danvers as she becomes one of the universe’s most powerful heroes when Earth is caught in the middle of a galactic war between two alien races. Set in the 1990s, Captain Marvel is an all-new adventure from a previously unseen period in the history of the Marvel Cinematic Universe.");
        Movie movie11 = new Movie("Dark Phoenix", "https://image.tmdb.org/t/p/w370_and_h556_bestv2/kZv92eTc0Gg3mKxqjjDAM73z9cy.jpg",
                "June 7, 2016",
                "The X-Men face their most formidable and powerful foe when one of their own, Jean Grey, starts to spiral out of control. During a rescue mission in outer space, Jean is nearly killed when she's hit by a mysterious cosmic force. Once she returns home, this force not only makes her infinitely more powerful, but far more unstable. The X-Men must now band together to save her soul and battle aliens that want to use Grey's new abilities to rule the galaxy.");

        movies.add(movie1);
        movies.add(movie2);
        movies.add(movie3);
        movies.add(movie4);
        movies.add(movie5);
        movies.add(movie6);
        movies.add(movie7);
        movies.add(movie8);
        movies.add(movie9);
        movies.add(movie10);
        movies.add(movie11);

        this.view.showMovies(movies);

    }

    public Movie getMovie(int index) {
        return movies.get(index);
    }
}
