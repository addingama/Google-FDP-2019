package com.google.fdp.moviecatalogue.view;

import com.google.fdp.moviecatalogue.model.Movie;

import java.util.ArrayList;

/**
 * Created by gama on 2019-07-01.
 * Addin Gama Bertaqwa
 * addingama@gmail.com
 */
public interface MoviesView {
    void showMovies(ArrayList<Movie> movies);
}
