// main function
fun main() {
    val company = "Dicoding"
    println(company.reversed())
    println(company.toUpperCase())
    println(company.toLowerCase())
}