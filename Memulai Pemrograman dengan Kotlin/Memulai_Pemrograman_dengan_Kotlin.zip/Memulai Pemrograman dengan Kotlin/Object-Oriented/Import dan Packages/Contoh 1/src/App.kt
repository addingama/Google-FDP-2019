import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sqrt

// main function
fun main(){
    println(PI)
    println(cos(120.0))
    println(sqrt(9.0))
}