// main function
fun main() {
    var counter = 1

    while (counter <= 7){
        println("Hello, World!")
        counter++
    }
}