// main function
fun main() {
    val text  = "Kotlin"
    for (char in text){
        print("$char ")
    }
}